#### Начало работы ####

# Определяем какая сейчас рабочая папка
getwd()

# Устанавливаем новую рабочую папку
setwd("C:/Users/User/Documents/code/lesson1")

##### Типы данных #####

# numeric является общим типом для всех числовых данных.
val <- 5
typeof(val)
class(val)

val <- 5.6
typeof(val)
class(val)

# integer - частный подтип типа numeric. 
# При конвертации может потерять дробную часть.
val <- as.integer(5.6)
val
typeof(val)
class(val)

# Числа можно преобразовывать в текст.
val <- as.character(5.6)
typeof(val)
class(val)

# Числа можно получать из текста.
val <- as.numeric("5.6")
class(val)
typeof(val)
val

# Это иллюстрация динамической типизации R: 
# тип переменной определяется в момент записи в нее данных

# Но нужно помнить, что десятичным разделителем по умолчанию является точка.
val <- as.numeric("5,6")
val

# Даты можно получать из текста.
val <- as.Date("2024-02-17")
val
typeof(val)
class(val)

# Но для даты со временем нужен отдельный тип.
val <- as.Date("2024-02-17 23:56:12")
val
typeof(val)
class(val)

# Конвертация в дату-время немного сложнее.
val <- as.POSIXct("2024-02-17 23:56:12", format="%Y-%m-%d %H:%M:%S", tz="UTC")
val
typeof(val)
class(val)

# Конвертация обратно в текст происходит как обычно.
val <- as.character(val)
typeof(val)
class(val)
val

##### Очистка переменной #####

# NA - это тоже значение
val <- NA

# NULL - это тоже значение
val <- NULL

# Полное удаление
rm(val)
val

##### Имена переменных чувствительны к регистру #####

city <- "Смоленск"
City <- "Москва"

##### Математические операторы: арифметика #####

a <- 5
b <- 7

# Сложение
a + b

# Вычитание
a - b

# Деление
a / b
a / 0

# Целочисленное деление
b %/% a

# Остаток от деления
b %% a

# Умножение
a * b

# Возведение в степень
a ^ 2
b ** 2

# Модуль числа
abs(-1)

# Квадратный корень из числа
sqrt(b)

# Экспонента ex
exp(1)

# Натуральный логарифм lnx
log(3)

# Десятичный логарифм
log10(1000)

# Логарифм с основанием y
log(8, 2)

##### Математические операторы: округление #####

# Наибольшее целое, не превосходящее данное число
floor(3.88)

# Округление данного числа x до n знаков после запятой
round(3.456, 2)

# Округление в большую сторону
ceiling(3.3)

# Отсечение дробной части
trunc(-3.4)

# Округляет x до заданного числа значащих цифр
signif(3.479, 2)


##### Операторы сравнения и логические операторы #####

a <- 5
b <- 6
a>b

# Равно
5 == 6

# Не равно
5 != 6

# Меньше
5 < 6

# Больше
5 > 6

# Меньше или равно
6 <= 6

# Больше или равно
5 >= 6

# Операторы проверки на значения
val <- "text"

is.numeric(val)

val <- NA

is.na(val)

# Логическое И
TRUE & FALSE
TRUE & TRUE
FALSE & TRUE
FALSE & FALSE

# Логическое ИЛИ
TRUE | FALSE
TRUE | TRUE
FALSE | TRUE
FALSE | FALSE

# Логическое НЕ!TRUE
!FALSE
!TRUE

#### Условные переходы ####

##### Проверка условий: один вариант выбора #####

cat <- "Спит"
if (cat == "Мяукает"){
  print("Покормить кота")
}
print("Погладить кота")

# Условие не выполняется
cat <- "Спит"
if (cat == "Мяукает"){
  print("Покормить кота")
}
print("Погладить кота")

##### Проверка условий: два варианта выбора #####

today <- "среда"
if (today == "среда"){
  # Условие выполняется
  print("слушаем лекцию")
} else {
  # Условие не выполняется
  print("смотрим сериалы")
}

today <- "пятница"
if (today == "среда"){
  # Условие не выполняется
  print("слушаем лекцию")
} else {
  # Условие выполняется
  print("смотрим сериалы")
}

##### Проверка условий: несколько вариантов #####

light <- "красный"

if (light == "красный"){
  print("стоим")
} else if (light == "желтый") {
  print("ждем")
} else if (light == "зеленый") {
  print("идем")
} else {
  print("ждем когда загорится")
}

light <- "черный"

result <- switch(
  light,
  "красный" = "стоим",
  "желтый" = "ждем",
  "зеленый" = "идем",
  "ждем когда загорится"  # значение по умолчанию (без имени)
)

print(result)


# При проверке можно комбинировать и несколько условий
age <- 56
status <- ""
if (age >= 18 & age <= 44 ){
  status <- "Молодой возраст"
} else if (age >= 45 & age <= 59) {
  status = "Средний возраст"
} else if (age >= 60 & age <= 74) {
  status = "Пожилой возраст"
} else if (age >= 75 & age <= 90) {
  status = "Старческий возраст"
} else if (age > 90) {
  status = "Долголетие"
} else {
  status = "ребенок"
}
status


#### Циклы ####

##### for #####

# Повторяем одно действие 10 раз
for (i in 1:10) {
  print(i)
}

# Операторы управления циклом
for (i in 1:10) {
  if (i < 3)
    next # переводит на следующую итерацию цикла
  
  print(i)
  
  if (i >= 5)
    break # прерывает выполнение текущей итерации цикла
}
print("FIN")


##### while #####

# while(condition) выполняет команду, пока заданное условие
# не перестанет быть истинным

i <- 5 # Переменная, отвечающая за выполнение цикла
while (i > 0) {
  print("Hello")
  i <- i - 1 # Изменяем переменную внутри цикла
}
print("FIN")

##### repeat #####

# repeat(action) выполняет команду, пока не прервется командой break
i <- 10
repeat {
  i <- i - 1
  print("Hello")
  # Условие прерывания цикла
  if (i <= 5) {
    break; # Останавливаем цикл
  }
}
print("FIN")

##### Циклы и векторные операции #####

n <- 1e7
vec1 <- rnorm(n)
vec2 <- rnorm(n)

# Цикл
result_loop <- numeric(n)
system.time({
  for (i in 1:n) {
    result_loop[i] <- vec1[i] + vec2[i]
  }
})

# Векторная операция 
system.time({
  result_vectorized <- vec1 + vec2
})



#### Функции ####

# Объявление функции для расчета ИМТ
calcIMT <- function(weight, height) {
  res <- weight / (height ^ 2)
  return (res)
}

# Вызов функции
calcIMT(75, 1.70)

# Измененный порядок аргументов
calcIMT(height = 1.70, weight = 75)

# Необязательные аргументы
myPaste <- function(words, sep = ",") {
  res <- paste(words, collapse = sep)
  res
}

words <- c("one", "two", "three")

# Укажем символ для объединения слов
myPaste(words, sep = "+")

# Не будем указывать символ
myPaste(words)

# Загрузка функций из файла
source("_functions.R")

myPaste2(words)


#### Пакеты ####

# Список установленных пакетов
installed.packages()

# Установка пакета
install.packages("lubridate")

# Использование пакета
library(lubridate)

# Проверка установки пакета. 
# Если он отсутствует, пакет будет установлен и загружен
if (!require(lubridate)) { 
  install.packages("lubridate")
  library(lubridate)  
}

testdate <- ymd("2025-10-29")

#### Наборы данных ####

# Посмотреть все доступные наборы
help(package='datasets')
?datasets

# Motor Trend Car Road Tests
mtcars
# Edgar Anderson's Iris Data
iris

# Monthly Deaths from Lung Diseases in the UK
mdeaths # males
fdeaths # females
ldeaths # both sexes

# Infertility after Spontaneous and Induced Abortion
infert

# Pharmacokinetics of Indomethacin
Indometh

# Smoking, Alcohol and (O)esophageal Cancer
esoph


##### Функции для оценки наборов данных #####

iris        # Показать полное содержимое
View(iris)  # Открыть во встроенном просмотрщике RStudio

nrow(iris) # Количество строк

ncol(iris) # Количество столбцов

colnames(iris)   # Имена столбцов

rownames(mtcars) # Имена строк

str(iris)   # Оценить структуру набора

head(iris)   # Показать первые 6 строк
tail(iris)   # Показать последние 6 строк

summary(iris)   # Оценить суммарные метрики набора

##### Встроенные статистические функции #####

# Оператор $ позволяет обратиться к одному столбцу набора данных
iris$Sepal.Length

# Сумма всех значений
sum(iris$Sepal.Width)

# Минимум и максимум
min(iris$Sepal.Width)

# Среднее арифметическое
mean(iris$Sepal.Width)

# При расчете агрегирующих функций не должно быть пропущенных значений
values <- c(1,2,3,4,NA,5,6,NA,7)
mean(values)

mean(values, na.rm = TRUE)

# Медиана
median(iris$Sepal.Width)

# Стандартное отклонение
sd(iris$Sepal.Width)

# Квантили / Процентиль / квартиль
quantile(iris$Sepal.Width)


##### Функции внутри функции #####

describe_vector <- function(x, digits = 2) {
  # Проверка: вектор ли это и не пустой ли
  if (!is.numeric(x)) return("Аргумент 'x' должен быть числовым вектором.")
  if (length(x) == 0) return("Вектор 'x' пуст.")
  
  N  <- paste("N =", length(x))
  AVG <- round(mean(x, na.rm = TRUE), digits)
  SD  <- round(sd(x, na.rm = TRUE), digits)
  AVGSD <- paste("AVGSD:", paste0(AVG, " \u00B1 ", SD))
  Me  <- round(median(x, na.rm = TRUE), digits)
  Q1  <- round(quantile(x, 0.25, na.rm = TRUE), digits)
  Q3  <- round(quantile(x, 0.75, na.rm = TRUE), digits)
  MeQ1Q3 <- paste0("MeQ1Q3:", Me, " (", Q1, "; ", Q3, ")")
  Min <- paste("Min:", round(min(x, na.rm = TRUE), digits))
  Max <- paste("Max:", round(max(x, na.rm = TRUE), digits))
  
  # Формируем итоговую строку
  result <- paste(N, AVGSD, MeQ1Q3, Min, Max, sep = ", ")
  
  return(result)
}
describe_vector(iris$Sepal.Width)


