myPaste2 <- function(words, sep = "2") {
  res <- paste(words, collapse = sep)
  res
}